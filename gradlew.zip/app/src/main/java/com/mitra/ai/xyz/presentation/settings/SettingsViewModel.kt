package com.mitra.ai.xyz.presentation.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.mitra.ai.xyz.domain.model.AiProvider
import com.mitra.ai.xyz.domain.model.AiProviderType
import com.mitra.ai.xyz.domain.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SettingsState(
    val providers: List<AiProvider> = listOf(
        AiProvider(
            type = AiProviderType.OPENAI,
            name = "OpenAI",
            isActive = true
        ),
        AiProvider(
            type = AiProviderType.ANTHROPIC,
            name = "Anthropic"
        ),
        AiProvider(
            type = AiProviderType.GOOGLE,
            name = "Google AI"
        ),
        AiProvider(
            type = AiProviderType.CUSTOM,
            name = "Custom Provider"
        )
    ),
    val selectedProvider: AiProvider? = null,
    val availableModels: List<String> = emptyList(),
    val isLoadingModels: Boolean = false,
    val currentConfig: ProviderConfig? = null,
    val error: String? = null,
    val saveStatus: SaveStatus? = null
)

data class ProviderConfig(
    val apiKey: String = "",
    val baseUrl: String = "",
    val model: String = ""
)

enum class SaveStatus {
    SUCCESS,
    ERROR
}

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _settingsState = MutableStateFlow(SettingsState())
    val settingsState: StateFlow<SettingsState> = _settingsState

    init {
        loadSettings()
    }

    private fun loadSettings() {
        viewModelScope.launch {
            try {
                val activeProvider = settingsRepository.getActiveProviderOnce()
                val config = settingsRepository.getProviderConfig()
                
                _settingsState.update { state ->
                    state.copy(
                        providers = state.providers.map { provider ->
                            provider.copy(isActive = provider.type.name == activeProvider)
                        },
                        selectedProvider = state.providers.find { it.type.name == activeProvider },
                        currentConfig = ProviderConfig(
                            apiKey = config.apiKey,
                            baseUrl = config.baseUrl,
                            model = config.model
                        ),
                        error = null,
                        saveStatus = null
                    )
                }
            } catch (e: Exception) {
                _settingsState.update { it.copy(error = e.message) }
            }
        }
    }

    fun setActiveProvider(provider: AiProvider) {
        viewModelScope.launch {
            try {
                settingsRepository.setActiveProvider(provider.type.name)
                _settingsState.update { state ->
                    state.copy(
                        providers = state.providers.map { p ->
                            p.copy(isActive = p.type == provider.type)
                        },
                        selectedProvider = provider,
                        availableModels = emptyList(),
                        error = null,
                        saveStatus = null
                    )
                }
            } catch (e: Exception) {
                _settingsState.update { it.copy(error = e.message) }
            }
        }
    }

    fun fetchAvailableModels(apiKey: String, baseUrl: String?) {
        viewModelScope.launch {
            try {
                _settingsState.update { it.copy(isLoadingModels = true, error = null) }
                
                val models = settingsRepository.fetchAvailableModels(apiKey, baseUrl)
                
                _settingsState.update { state ->
                    state.copy(
                        availableModels = models,
                        isLoadingModels = false,
                        error = null
                    )
                }
            } catch (e: Exception) {
                _settingsState.update { state ->
                    state.copy(
                        isLoadingModels = false,
                        error = "Failed to fetch models: ${e.message}"
                    )
                }
            }
        }
    }

    fun updateProviderConfig(
        apiKey: String,
        baseUrl: String = "",
        model: String = ""
    ) {
        viewModelScope.launch {
            try {
                _settingsState.update { it.copy(error = null, saveStatus = null) }
                
                settingsRepository.updateProviderConfig(
                    apiKey = apiKey,
                    baseUrl = baseUrl,
                    model = model
                )
                
                _settingsState.update { state ->
                    state.copy(
                        currentConfig = ProviderConfig(
                            apiKey = apiKey,
                            baseUrl = baseUrl,
                            model = model
                        ),
                        saveStatus = SaveStatus.SUCCESS,
                        error = null
                    )
                }

                // Clear success status after 2 seconds
                kotlinx.coroutines.delay(2000)
                _settingsState.update { it.copy(saveStatus = null) }
                
            } catch (e: Exception) {
                _settingsState.update { it.copy(
                    error = "Failed to save configuration: ${e.message}",
                    saveStatus = SaveStatus.ERROR
                ) }
            }
        }
    }

    fun clearError() {
        _settingsState.update { it.copy(error = null, saveStatus = null) }
    }
} 