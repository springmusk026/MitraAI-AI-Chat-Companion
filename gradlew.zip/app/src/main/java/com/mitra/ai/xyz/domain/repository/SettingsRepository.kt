package com.mitra.ai.xyz.domain.repository

import kotlinx.coroutines.flow.Flow

data class ProviderConfig(
    val apiKey: String = "",
    val baseUrl: String = "",
    val model: String = ""
)

interface SettingsRepository {
    suspend fun getApiKey(): String
    suspend fun getActiveProviderOnce(): String
    suspend fun setActiveProvider(provider: String)
    fun getActiveProviderFlow(): Flow<String>
    suspend fun updateProviderConfig(
        apiKey: String,
        baseUrl: String = "",
        model: String = ""
    )
    suspend fun getProviderConfig(): ProviderConfig
    suspend fun fetchAvailableModels(apiKey: String, baseUrl: String? = null): List<String>
}