package com.mitra.ai.xyz.domain.model

enum class AiProviderType {
    OPENAI,
    ANTHROPIC,
    GOOGLE,
    CUSTOM
}

data class AiProvider(
    val type: AiProviderType,
    val name: String,
    val apiKey: String = "",
    val baseUrl: String = "",
    val model: String = "",
    val temperature: Float = 0.7f,
    val maxTokens: Int = 2000,
    val isActive: Boolean = false
) 