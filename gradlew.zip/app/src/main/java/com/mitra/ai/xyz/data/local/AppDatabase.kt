package com.mitra.ai.xyz.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.mitra.ai.xyz.domain.model.Chat
import com.mitra.ai.xyz.domain.model.Message

@Database(
    entities = [Message::class, Chat::class],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun messageDao(): MessageDao
    abstract fun chatDao(): ChatDao

    companion object {
        const val DATABASE_NAME = "mitra_ai_db"
    }
}