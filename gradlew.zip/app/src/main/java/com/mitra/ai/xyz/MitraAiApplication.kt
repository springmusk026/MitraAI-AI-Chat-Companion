package com.mitra.ai.xyz

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MitraAiApplication : Application() 